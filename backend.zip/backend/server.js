<<<<<<< HEAD
// ===============================
// server.js — версия с логированием и Socket.IO
// ===============================
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const connectDatabase = require('./config/database');
const requestLogger = require('./middleware/requestLogger'); // 🆕 лог мидлвэр
const loggerUtil = require('./utils/logger'); // 🆕 наш winston логгер
=======
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDatabase = require('./config/database');
>>>>>>> 829b470352a991ddc84f1f3bceb39b90988a125c

dotenv.config();
connectDatabase();

const app = express();
<<<<<<< HEAD
app.use(express.json());
app.use(cors());

// === Подключаем логгер запросов ===
app.use(requestLogger);

// === Основные маршруты ===
=======

app.use(express.json());
app.use(cors());

// Маршруты
>>>>>>> 829b470352a991ddc84f1f3bceb39b90988a125c
app.use('/api/auth', require('./routes/auth'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/submissions', require('./routes/submissions'));
app.use('/api/leaderboard', require('./routes/leaderboard'));
<<<<<<< HEAD
app.use('/api/groups', require('./routes/groups'));
app.use('/api/logs', require('./routes/logs')); // 🆕 новый роут логов

// === Тестовый эндпоинт ===
=======
app.use('/api/groups', require('./routes/groups')); // НОВОЕ

>>>>>>> 829b470352a991ddc84f1f3bceb39b90988a125c
app.get('/', (req, res) => {
    res.json({ 
        message: 'Gamified Programming Platform API',
        version: '2.0.0',
        features: [
            'Authentication',
            'Tasks with deadlines',
            'Submissions with edit/delete',
            'Groups management',
            'Task assignment to groups',
<<<<<<< HEAD
            'Detailed statistics',
            'Live logging system 🧠'
=======
            'Detailed statistics'
>>>>>>> 829b470352a991ddc84f1f3bceb39b90988a125c
        ]
    });
});

<<<<<<< HEAD
// === Создаём HTTP сервер и Socket.IO ===
const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: "*", // Можно ограничить адресом фронтенда
        methods: ["GET", "POST"]
    }
});

// === Инициализация логгера с io ===
loggerUtil.init(io);

// === Обработка подключений Socket.IO ===
io.on('connection', (socket) => {
    console.log(`🟢 WebSocket подключен: ${socket.id}`);
    socket.emit('server_message', 'Добро пожаловать в систему логов!');

    socket.on('disconnect', () => {
        console.log(`🔴 WebSocket отключён: ${socket.id}`);
    });
});

const PORT = process.env.PORT || 5000;

// === Запуск сервера ===
server.listen(PORT, () => {
    loggerUtil.info(`🚀 Сервер запущен на порту ${PORT}`);
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
});
=======
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
});
>>>>>>> 829b470352a991ddc84f1f3bceb39b90988a125c
